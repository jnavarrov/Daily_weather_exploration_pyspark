
# coding: utf-8

# In[33]:

from pyspark.sql import SQLContext
from pyspark.sql import DataFrameNaFunctions
from pyspark.ml import Pipeline
from pyspark.ml.classification import DecisionTreeClassifier
from pyspark.ml.feature import Binarizer
from pyspark.ml.feature import VectorAssembler, StringIndexer, VectorIndexer


# In[34]:

sqlContext = SQLContext(sc)
df = sqlContext.read.load('file:///home/cloudera/Downloads/big-data-4/daily_weather.csv', 
                          format='com.databricks.spark.csv', 
                          header='true',inferSchema='true')
df.columns


# In[35]:

featureColumns = ['air_pressure_9am','air_temp_9am','avg_wind_direction_9am','avg_wind_speed_9am',
        'max_wind_direction_9am','max_wind_speed_9am','rain_accumulation_9am',
        'rain_duration_9am']


# In[36]:

df = df.drop('number')


# In[37]:

df.columns


# In[38]:

df = df.na.drop()


# In[39]:

df.count(), len(df.columns)


# In[40]:

binarizer = Binarizer(threshold=24.99999, inputCol ="relative_humidity_3pm", outputCol="label")
binarizerDF = binarizer.transform(df)


# In[41]:

binarizerDF.select("relative_humidity_3pm","label").show(4)


# In[42]:

assembler = VectorAssembler(inputCols=featureColumns, outputCol="features")
assembled = assembler.transform(binarizerDF)


# In[43]:

(trainingData, testData) = assembled.randomSplit([0.8,0.2], seed = 13234)


# In[44]:

dt = DecisionTreeClassifier(labelCol="label", featuresCol="features", maxDepth=5,
                           minInstancesPerNode=20, impurity ="gini")


# In[46]:

pipeline = Pipeline(stages=[dt])
model = pipeline.fit(trainingData)


# In[47]:

predictions = model.transform(testData)


# In[48]:

predictions.select("prediction", "label").show(10)


# In[50]:

predictions.select("prediction", "label").write.save(path="file:///home/cloudera/Downloads/big-data-4/predictions.csv",
                                                     format ="com.databricks.spark.csv", header = 'true')


# In[ ]:




# In[ ]:




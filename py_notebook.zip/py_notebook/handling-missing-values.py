
# coding: utf-8

# In[1]:

from pyspark.sql import SQLContext

sqlContext = SQLContext(sc)

df = sqlContext.read.load('file:///home/cloudera/Downloads/big-data-4/daily_weather.csv', 
                          format='com.databricks.spark.csv', 
                          header='true',inferSchema='true')


# In[2]:

df.describe().toPandas().transpose()


# In[4]:

df.describe('air_temp_9am').show()


# In[5]:

df.count()


# In[13]:

removeAllDF = df.na.drop()


# In[14]:

removeAllDF.describe("air_temp_9am").show()


# In[16]:

removeAllDF.count()


# In[11]:

from pyspark.sql.functions import avg
imputeDF = df


# In[17]:

for x in imputeDF.columns:
    meanValue = removeAllDF.agg(avg(x)).first()[0]
    print(x, meanValue)
    imputeDF = imputeDF.na.fill(meanValue, [x])


# In[18]:

df.describe(["air_temp_9am"]).show()
imputeDF.describe(["air_temp_9am"]).show()


# In[21]:

df.describe(["air_pressure_9am"]).show()


# In[22]:

df.count()


# In[ ]:




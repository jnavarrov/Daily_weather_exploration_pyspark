
# coding: utf-8

# In[6]:

from pyspark.sql import SQLContext
from pyspark.ml.evaluation import MulticlassClassificationEvaluator
from pyspark.mllib.evaluation import MulticlassMetrics


# In[7]:

sqlContext = SQLContext(sc)
predictions = sqlContext.read.load('file:///home/cloudera/Downloads/big-data-4/predictions.csv', 
                          format='com.databricks.spark.csv', 
                          header='true',inferSchema='true')


# In[34]:

evaluator = MulticlassClassificationEvaluator(
    labelCol="label", predictionCol="prediction", metricName="precision")



# In[35]:

accuracy = evaluator.evaluate(predictions)
print("accuracy = %.2g" % (accuracy * 100))


# In[16]:

predictions.rdd.take(2)


# In[17]:

predictions.rdd.map(tuple).take(2)


# In[20]:

metrics = MulticlassMetrics(predictions.rdd.map(tuple))


# In[22]:

metrics.confusionMatrix().toArray().transpose()


# In[ ]:





# coding: utf-8

# In[3]:

from pyspark.sql import SQLContext
from pyspark.ml.clustering import KMeans
from pyspark.ml.feature import VectorAssembler
from pyspark.ml.feature import StandardScaler
from notebooks import utils
get_ipython().magic('matplotlib inline')


# In[4]:

sqlContext = SQLContext(sc)
df = sqlContext.read.load('file:///home/cloudera/Downloads/big-data-4/minute_weather.csv', 
                          format='com.databricks.spark.csv', 
                          header='true',inferSchema='true')


# In[5]:

df.count()


# In[42]:

filteredDF= df.filter((df.rowID % 5)== 0)
filteredDF.count()


# In[8]:

filteredDF.describe().toPandas().transpose()


# In[9]:

filteredDF.filter(filteredDF.rain_accumulation == 0).count()


# In[10]:

workingDF = filteredDF.drop('rain_duration').drop('rain_accumulation').drop('hpwren_timestamp')


# In[11]:

before = workingDF.count()
workingDF = workingDF.na.drop()
after = workingDF.count()
before - after


# In[12]:

workingDF.columns


# In[14]:

featuresUsed = ['air_pressure','air_temp','avg_wind_direction','avg_wind_speed','max_wind_direction','max_wind_speed', 'relative_humidity']
assembler = VectorAssembler(inputCols=featuresUsed, outputCol="features_unscaled")
assembled = assembler.transform(workingDF)


# In[16]:

scaler = StandardScaler(inputCol="features_unscaled", outputCol="features", withStd = True, withMean = True)
scalerModel= scaler.fit(assembled)
scaledData = scalerModel.transform(assembled)


# In[17]:

scaledData = scaledData.select("features", "rowID")
elbowset = scaledData.filter((scaledData.rowID % 3) == 0).select("features")
elbowset.persist()


# In[18]:

clusters = range(2,31)
wsselist = utils.elbow(elbowset, clusters)


# In[19]:

utils.elbow_plot(wsselist,clusters)


# In[20]:

scaledDataFeat = scaledData.select("features")
scaledDataFeat.persist()


# In[31]:

kmeans = KMeans(k=20, seed=1)
model = kmeans.fit(scaledDataFeat)
trnsformed = model.transform(scaledDataFeat)


# In[32]:

centers = model.clusterCenters()
centers


# In[37]:

P = utils.pd_centers(featuresUsed, centers)
utils.parallel_plot(P[P['relative_humidity']< -0.5],  P)


# In[25]:

utils.parallel_plot(P[P['air_temp']> 0.5], P)


# In[40]:

utils.parallel_plot(P[(P['relative_humidity']< -0.5) & (P['avg_wind_speed']>0.5)], P)


# In[36]:

utils.parallel_plot(P.iloc[[2]], P)


# In[ ]:



